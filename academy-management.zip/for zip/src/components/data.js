var studentArray = [{
    id: 1,
    name: 'Jayesh',
    currentClass: 5,
    division: 'A'
},
{
    id: 2,
    name: 'Minakshi',
    currentClass: 12,
    division: 'C'
}]